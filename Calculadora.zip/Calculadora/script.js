let display = document.getElementById("display")
let entrada=""
let operador=""


function addnumber(values){
    entrada += values
    display.textContent = entrada
}

function addoperador(operator){
     if (entrada == "" && operator !=".")return
     entrada += operator
     display.textContent = entrada
}

function calculador(){
    try {
        let result = eval(entrada)
        if(!Number.isInteger(result)){
          result = result.toFixed(2)
        }
        entrada = result
        display.textContent= entrada
        
    } catch (error) {
        display.textContent = "Error"
        display.textContent = ""
    }
}

function limpar(){
    entrada = ""
    display.textContent = entrada
}