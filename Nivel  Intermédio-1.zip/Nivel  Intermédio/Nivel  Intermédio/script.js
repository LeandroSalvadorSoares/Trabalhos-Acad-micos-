  let contador = parseInt(localStorage.getItem("contador")) || 0;

  const numeroElemento = document.getElementById("numero");

  // Atualiza visual na carga da página
  atualizarContador(contador);

  // Botão de adicionar
  document.getElementById("botao").addEventListener("click", function () {
    contador++;
    if (contador === 10) {
      alert("Parabéns");
    }
    atualizarContador(contador);
  });

  // Botão de reduzir
  document.getElementById("botaoReduzir").addEventListener("click", function () {
    contador--;
    atualizarContador(contador);
  });

  // Função que atualiza número, cor e salva no localStorage
  function atualizarContador(valor) {
    numeroElemento.textContent = valor;
    localStorage.setItem("contador", valor);

    if (valor > 0) {
      numeroElemento.style.color = "green";
    } else if (valor < 0) {
      numeroElemento.style.color = "red";
    } else {
      numeroElemento.style.color = "black";
    }
  }

