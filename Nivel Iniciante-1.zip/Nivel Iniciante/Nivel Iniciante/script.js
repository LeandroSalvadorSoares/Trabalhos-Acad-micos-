// Cria uma variável chamada "contador" e a inicializa com o valor 0
let contador = 0;

// Seleciona o botão com o id "botao" e adiciona um ouvinte de evento de clique
document.getElementById("botao").addEventListener("click", function () {
  
  // Quando o botão é clicado, incrementa o valor da variável "contador"
  contador++;
  
  // Atualiza o conteúdo do parágrafo com id "contador" para mostrar o novo valor
  document.getElementById("numero").textContent = contador;
});

// Seleciona o botão com o id "botaoZerar" e adiciona um ouvinte de evento de clique
document.getElementById("botaozerar").addEventListener("click", function () {
  
  // Quando o botão é clicado, incrementa o valor da variável "contador"
  contador = 0;
  
  // Atualiza o conteúdo do parágrafo com id "contador" para mostrar o novo valor
  document.getElementById("numero").textContent = contador;
});


// Seleciona o botão com o id "botaoReduzir" e adiciona um ouvinte de evento de clique
document.getElementById("botaoReduzir").addEventListener("click", function () {
  
  // Quando o botão é clicado, incrementa o valor da variável "contador"
  contador--;
  if (contador < 0) {
    contador = 0;
  }
  
  // Atualiza o conteúdo do parágrafo com id "contador" para mostrar o novo valor
  document.getElementById("numero").textContent = contador;
});


  